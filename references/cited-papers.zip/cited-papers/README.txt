FINAL THESIS — CITED SOURCES

Scope: exactly the 48 citation keys used in the final paired Overleaf examplethesis.tex (all chapters and appendices).
45 scholarly PDFs, including 39 local Zotero PDFs and six recovered public copies; three additional citations are web resources, with URL shortcuts and available HTML snapshots.
The Coming Age of Calm Technology is the 1996 author manuscript corresponding to the cited 1997 book chapter, labelled in manifest.json. The Crazy 8s URL currently serves a different landing page, so only its original URL is retained.

Zotero highlights, underlines, ink, text annotations and comments are embedded as standard PDF annotations. All 453 active stored annotations are also preserved with exact positions, colours, text, comments, tags and keys in *.annotations.json sidecars. Original Zotero files were not altered. Existing native PDF annotations are retained.

manifest.json maps citation keys to files, Zotero keys, original/archived SHA-256 hashes and public download locations. cited-references.bib contains only the cited bibliography records. verification.json records file integrity and PDF rendering checks.

This archive contains source documents and annotation exports only; no literature notes, wiki or syntheses. Copyright and licences remain with the original rights holders; public redistribution permissions have not been established.
